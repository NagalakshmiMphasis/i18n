module.exports = require("nativescript-dev-webpack/lib/before-watchPatterns.js");
