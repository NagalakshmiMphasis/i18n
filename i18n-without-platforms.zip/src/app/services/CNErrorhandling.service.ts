import { Injectable } from "@angular/core";
import { HttpInterceptor, HttpHandler, HttpRequest, HttpEvent, HttpErrorResponse } from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { catchError, tap} from 'rxjs/operators';

@Injectable()
export class CNErrorhandlingservice implements HttpInterceptor {
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
   // const customReq = request.clone({  });
    return next.handle(request)
    .pipe(
    //   tap((msg: any) => {
    //   console.log("check msg",msg)
    //  }), // this is the place where  all http requests are passing 
    catchError((error:HttpErrorResponse) => {
      let errormsg;
       if(error instanceof HttpErrorResponse){
        //server side error
        if(error.status == 400){
         console.log("Status 400: Bad request")
       }else if(error.status == 500){
         console.log("Status 500: Internal Server Error")
       }else if(error.status == 403){
         console.log("Status 403:  Forbidden") 
       }else if(error.status == 401){
         console.log("Status 401:  Unauthorized") 
       }else if(error.status == 404){
         console.log("Status 404: Not Found") 
       }
        errormsg =`Error Code: ${error.status}\n Message: ${error.message}`;
      // errormsg =`${error.error }`;

        console.log("errorcheck1", errormsg)
     }
      else {
        //client side error
        // errormsg = `Error: ${erro.message}`;
        errormsg =`${error}`;
         console.log("errorcheck2",  errormsg)
       }
      
      
      
    //  else{
    //     console.log(error)
    //   }
      
      return throwError(errormsg);
      
    })
    );
    
    
  }





// handleError(error:HttpErrorResponse) {
//   if(error instanceof ErrorEvent){
//   console.error("client side", error.message);
//   //console.log("Error in Observable");
//   }else{
//     //Backend returns unsuccessful response codes such as 404, 500 etc.				  
//         console.error('Backend returned status code: ', error.status);
//         console.error('Response body:', error.message);
//   }
//   return Observable.throw(error);
// }
}