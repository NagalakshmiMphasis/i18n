import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders  } from "@angular/common/http";
import { Observable, from } from 'rxjs';
import { map } from "rxjs/operators";
import { catchError } from 'rxjs/operators';
import { Emp } from '../models/emp';
import { DomSanitizer,SafeResourceUrl, SafeUrl } from '@angular/platform-browser';

@Injectable()
export class EmpService {
  //private sanitizer: DomSanitizer
     constructor(public http: HttpClient) {
    }
  // public url:SafeUrl;
    getData(): Observable<any> {
       //console.log("get data method")
        return this.http.get('http://dummy.restapiexample.com/api/v1/employee')
      // this.url  = this.sanitizer.bypassSecurityTrustResourceUrl('https://jsonplaceholder.typicode.com/todos'); 
          //  return this.http.get<Emp[]>('https://jsonplaceholder.typicode.com/todos')
            //.pipe(map(response => response.json().resu));
    }
    
}