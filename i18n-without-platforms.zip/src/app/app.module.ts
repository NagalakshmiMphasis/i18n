import { NgModule, Component} from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { EmpdataComponent } from './components/empdata/empdata.component';
import { BaseErrorHandlingModule } from './modules/base-error-handling/base-error-handling.module';
import { CNErrorhandlingservice } from './services/CNErrorhandling.service';
import {  HttpClient, HTTP_INTERCEPTORS, HttpClientModule } from '@angular/common/http';
import { LogService } from './services/log.service';
import { EmpService } from './services/emp.service';
import { FormsModule } from '@angular/forms';
// import ngx-translate and the http loader
import {TranslateLoader, TranslateModule} from '@ngx-translate/core';
import {TranslateHttpLoader} from '@ngx-translate/http-loader';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    EmpdataComponent,
  ],
  imports: [
  BrowserModule,
  AppRoutingModule, BaseErrorHandlingModule, FormsModule, HttpClientModule,
  TranslateModule.forRoot({
    loader: {
        provide: TranslateLoader,
        useFactory: HttpLoaderFactory,
        deps: [HttpClient]
    }
})
  ],
  providers: [LogService, EmpService, { provide: HTTP_INTERCEPTORS, useClass: CNErrorhandlingservice, multi: true }],
  bootstrap: [AppComponent]
})
export class AppModule { }

// required for AOT compilation
export function HttpLoaderFactory(http: HttpClient) {
 // return new TranslateHttpLoader(http);
 return new TranslateHttpLoader(http, '/assets/i18n/', '.json');
}