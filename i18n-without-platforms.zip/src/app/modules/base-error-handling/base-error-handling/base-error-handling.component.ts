import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-base-error-handling',
  templateUrl: './base-error-handling.component.html',
  styleUrls: ['./base-error-handling.component.css']
})
export class BaseErrorHandlingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
