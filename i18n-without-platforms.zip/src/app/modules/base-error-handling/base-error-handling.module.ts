import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BaseErrorHandlingComponent } from './base-error-handling/base-error-handling.component';

@NgModule({
  declarations: [BaseErrorHandlingComponent],
  imports: [
    CommonModule
  ],
  exports:[BaseErrorHandlingComponent]
})
export class BaseErrorHandlingModule { }
