
export class Emp {
    id?: string;
    title:string;
    empname:any;
    employeesal:any;
    employeeage:any;
    profileima:any;

    
}
